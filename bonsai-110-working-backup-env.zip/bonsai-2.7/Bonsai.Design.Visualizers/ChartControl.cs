﻿using System;

namespace Bonsai.Design.Visualizers
{
    /// <summary>
    /// Provides a legacy graph control type.
    /// </summary>
    [Obsolete]
    public class ChartControl : GraphControl
    {
    }
}
