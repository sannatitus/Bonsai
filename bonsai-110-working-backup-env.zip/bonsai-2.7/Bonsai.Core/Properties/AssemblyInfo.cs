﻿using Bonsai;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: XmlNamespacePrefix("clr-namespace:Bonsai.Reactive", "rx")]
[assembly: WorkflowNamespaceIcon("Bonsai.Reactive", "Bonsai:ElementIcon.Reactive")]
[assembly: WorkflowNamespaceIcon("Bonsai.Expressions", "Bonsai:ElementIcon.Numerics")]
