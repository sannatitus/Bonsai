﻿namespace Bonsai.Expressions
{
    interface IGroupWorkflowBuilder : IWorkflowExpressionBuilder, IRequireBuildContext
    {
    }
}
