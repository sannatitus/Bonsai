﻿namespace Bonsai.Expressions
{
    interface ISerializableElement
    {
        object Element { get; }
    }
}
