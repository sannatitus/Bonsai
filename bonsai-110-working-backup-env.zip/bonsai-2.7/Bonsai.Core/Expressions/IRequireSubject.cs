﻿namespace Bonsai.Expressions
{
    interface IRequireSubject : INamedElement, IRequireBuildContext
    {
    }
}
