﻿namespace Bonsai.Audio
{
    static class Constants
    {
        public const string XmlNamespace = "clr-namespace:Bonsai.Audio;assembly=Bonsai.Audio";
    }
}
